# pyscail

**pyscail** is a package for creating cellular automata. It allows you to specify the
allowed states, and the transitions between them, and does everything else for you

## Installation

You need to have python (>= 3.11) installed on your system. Once you have that,
you can:

```bash
pip install pyscail
```

(or `pip3`, depending on your system)

## Usage

## Demos
